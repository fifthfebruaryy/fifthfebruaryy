import { memo, SVGProps } from 'react';

const Line4StrokeIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 483 4' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      fillRule='evenodd'
      clipRule='evenodd'
      d='M483 3.50004L-2.62268e-07 3.5L0 0.5L483 0.500042L483 3.50004Z'
      fill='black'
    />
  </svg>
);

const Memo = memo(Line4StrokeIcon);
export { Memo as Line4StrokeIcon };
