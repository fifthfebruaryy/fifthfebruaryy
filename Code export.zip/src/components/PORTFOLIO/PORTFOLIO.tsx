import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Line4StrokeIcon } from './Line4StrokeIcon.js';
import classes from './PORTFOLIO.module.css';

interface Props {
  className?: string;
}
/* @figmaId 13:4 */
export const PORTFOLIO: FC<Props> = memo(function PORTFOLIO(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.vishnuMohananKdsTJ4qLfb0Unspla}></div>
      <div className={classes.dANIEL}>DANIEL</div>
      <div className={classes.rectangle33}></div>
      <div className={classes.professionalismIsAllToFixWhatI}>
        Professionalism is all. To fix what is broken is an art, a delicate one indeed. Here, I repair everything with
        love.
      </div>
      <div className={classes.line4Stroke}>
        <Line4StrokeIcon className={classes.icon} />
      </div>
      <div className={classes.cOMPUTERS}>COMPUTERS</div>
      <div className={classes._2023}>“2023</div>
      <div className={classes.ifeoluwaACgUhaShACEUnsplash1}></div>
    </div>
  );
});
